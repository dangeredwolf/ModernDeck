// TDEinject.js
// Copyright (c) 2014 Ryan Dolan (ryandolan123)

console.log("TDEinject loaded");

// TODO: do things here